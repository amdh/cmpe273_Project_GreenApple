Steps to set up Google Sheet API:

1. Create a project on Google Developers Console, Turn on Google Sheet API

2. Register Google API key

3. pip install --upgrade google-api-python-client

4. Add a python file to read sheets using google sheets ID

5. run the python file using “python readGoogleSheet.py”